package dataStructure;

class Node {
    int data;
 
    public Node() {
    }
     
    public Node(int data) {
        this.data = data;
    }
}



