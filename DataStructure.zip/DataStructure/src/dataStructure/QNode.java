package dataStructure;

class QNode {
    private int data;
 
    public QNode() {
    }
 
    public int getData() {
        return data;
    }
 
    public void setData(int data) {
        this.data = data;
    }
}